package app.aura.home;

import android.app.ActivityManager;
import android.content.Context;
import android.util.DisplayMetrics;

/**
 * Lite mode: every limit that matters on a 1 GB / ~500 MB-free TV (MediaTek MT9255L and friends) in
 * one place. It switches itself on when Android reports a low-memory device, or about 1.4 GB or
 * less of RAM, and can be forced either way with the Lite mode switch in Settings. Everything it changes is a
 * size, a count or a frame rate: the look of the home screen stays the same.
 */
final class Lite {
    static final String KEY = "set_lite";

    private static Boolean auto;
    private static Boolean cached;

    private Lite() { }

    /** True when this TV is short on RAM, whatever the switch says. */
    static boolean detected(Context c) {
        if (auto == null) {
            boolean low = false;
            try {
                ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) {
                    ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                    am.getMemoryInfo(mi);
                    // totalMem is what Android can use: a "1 GB" TV reports roughly 0.8 to 1.0 GB
                    low = am.isLowRamDevice() || (mi.totalMem > 0 && mi.totalMem <= 1_400L << 20);
                }
            } catch (RuntimeException ignored) {
            }
            auto = low;
        }
        return auto;
    }

    /** Whether lite mode is on: the user's choice if they made one, else what was detected. */
    static boolean on(Context c) {
        if (cached == null) cached = c.getSharedPreferences("aura", Context.MODE_PRIVATE).getBoolean(KEY, detected(c));
        return cached;
    }

    /** Settings flipped the switch: the next read sees it. */
    static void changed() {
        cached = null;
    }

    /** The longest side, in pixels, a photograph is decoded to: the screen, never more than the cap. */
    static int photoWidth(Context c) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int screen = Math.max(dm.widthPixels, dm.heightPixels);
        int cap = on(c) ? 1280 : 1536;
        return Math.max(960, Math.min(screen > 0 ? screen : cap, cap));
    }

    /**
     * Milliseconds between redraws of the drifting photograph while nothing else moves. The drift is
     * about 2 px a second, so 10 redraws a second look the same as 15. Measured in time rather than
     * frames so a 30 or 50 Hz TV isn't slower than a 60 Hz one. (60 and 92 sit just under 4 and 6
     * frames at 60 Hz.)
     */
    static long idleMs(Context c) {
        return on(c) ? 92 : 60;
    }

    /** Picture of the Day photographs kept on disk. */
    static int dailyKeep(Context c) {
        return on(c) ? 8 : 40;
    }

    /** How many past days of Picture of the Day the first import fetches. */
    static int dailyBacklog(Context c) {
        return on(c) ? 3 : 30;
    }

    /**
     * Photographs and GIFs sent from a phone that are kept. The same in lite mode: a photograph is
     * about 200 KB, so the count isn't what fills the disk. The total size ({@code Mine}) is what
     * keeps the oldest GIFs from doing that.
     */
    static int mineKeep(Context c) {
        return 60;
    }

    /** Largest single upload accepted from a phone. */
    static long uploadLimit(Context c) {
        return on(c) ? 12L << 20 : 40L << 20;
    }

    /** Posters kept for Tonight's pick. */
    static int picksPool(Context c) {
        return on(c) ? 12 : 30;
    }
}
