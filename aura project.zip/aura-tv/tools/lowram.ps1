# Low-RAM tuning for a 1 GB / ~500 MB-free TV (MediaTek MT9255L and similar), over ADB.
#
# Unlike debloat.ps1 (a fixed list for one Acer/Dixon model) this one LOOKS at what is installed and
# only ever touches packages from the list below that are really on your TV. It does a DRY RUN
# unless you add -Apply, and everything it does can be undone:
#   - packages are disabled with `pm disable-user` (nothing is uninstalled): restore.ps1 re-enables them
#   - run backup.ps1 first; this script refuses to change anything without that backup
#
#   .\tools\lowram.ps1                 show what it would do
#   .\tools\lowram.ps1 -Apply          do it
#   .\tools\lowram.ps1 -Apply -Aggressive   also: Chromecast built-in, phone-as-remote, Google ambient mode
#   .\tools\lowram.ps1 -Report         only list the biggest memory users and free space, change nothing
param(
    [string]$Tv = $env:AURA_TV,
    [switch]$Apply,
    [switch]$Aggressive,
    [switch]$Report
)
if (-not $Tv) { throw "Pass the TV's address, e.g. -Tv 192.168.1.50:5555, or set `$env:AURA_TV." }
$adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
if (-not (Test-Path $adb)) { $adb = "adb" }
$root = Split-Path -Parent $PSScriptRoot
$log = Join-Path $root "backup\lowram-log.txt"

& $adb connect $Tv | Out-Null
if (((& $adb -s $Tv get-state 2>&1) -join '') -notmatch 'device') { throw "TV $Tv is not reachable over ADB." }

# ---- what the TV has ----------------------------------------------------------------------------
"== This TV"
"   " + ((& $adb -s $Tv shell getprop ro.product.model) -join '')
"   Android " + ((& $adb -s $Tv shell getprop ro.build.version.release) -join '')
$mem = (& $adb -s $Tv shell cat /proc/meminfo) | Where-Object { $_ -match '^(MemTotal|MemAvailable):' }
$mem | ForEach-Object { "   $_" }
"== Storage (/data)"
(& $adb -s $Tv shell df /data) | ForEach-Object { "   $_" }

"== Biggest memory users right now (lastPss, from Android's own process list)"
$procs = @()
$name = $null
foreach ($line in (& $adb -s $Tv shell dumpsys activity processes)) {
    if ($line -match 'ProcessRecord\{\w+ \d+:([\w.]+)') { $name = $Matches[1]; continue }
    if ($name -and $line -match '^\s*lastPss=([\d.]+)(KB|MB|GB)') {
        $v = [double]$Matches[1]
        $kb = if ($Matches[2] -eq 'GB') { $v * 1024 * 1024 } elseif ($Matches[2] -eq 'MB') { $v * 1024 } else { $v }
        $procs += [pscustomobject]@{ Package = $name; MB = [math]::Round($kb / 1024) }
        $name = $null
    }
}
$procs | Group-Object Package | ForEach-Object { [pscustomobject]@{ Package = $_.Name; MB = ($_.Group | Measure-Object MB -Sum).Sum } } |
    Sort-Object MB -Descending | Select-Object -First 12 | ForEach-Object { "   {0,5} MB  {1}" -f $_.MB, $_.Package }
if ($Report) { return }

# ---- the candidates -----------------------------------------------------------------------------
# package (or prefix ending in *) = why it is safe to disable. All are optional extras: none is
# needed to watch TV, use HDMI, Wi-Fi, Bluetooth or any streaming app.
$safe = [ordered]@{
    "com.google.android.youtube.tvmusic"            = "YouTube Music"
    "com.google.android.videos"                     = "Google Play Movies & TV (store, home promos)"
    "com.google.android.play.games"                 = "Play Games"
    "com.google.android.feedback"                   = "Google Feedback: crash and usage reports"
    "com.google.android.onetimeinitializer"         = "One-time setup initializer"
    "com.google.android.partnersetup"               = "Partner setup / promo client IDs"
    "com.google.android.syncadapters.calendar"      = "Calendar sync"
    "android.autoinstalls.config.*"                 = "Play Auto Installs: pushes promoted apps"
    "com.android.printspooler"                      = "Print spooler (no printing on a TV)"
    "com.android.bips"                              = "Default print service"
    "com.android.retaildemo"                        = "Store demo mode"
    "com.google.android.retaildemo"                 = "Store demo mode"
    "com.mediatek.mtklogger"                        = "MediaTek logger: writes logs to storage"
    "com.debug.loggerui"                            = "MediaTek debug logger UI"
    "com.mediatek.engineermode"                     = "MediaTek engineer menu"
    "com.mediatek.factorymode"                      = "MediaTek factory test"
}
# things many people do use, so they are only touched with -Aggressive
$optional = [ordered]@{
    "com.google.android.apps.mediashell"            = "Chromecast built-in (casting to this TV)"
    "com.google.android.tv.remote.service"          = "Phone-as-remote service"
    "com.google.android.apps.tv.dreamx"             = "Google ambient screensaver (Aura has its own)"
}
$targets = [ordered]@{}
foreach ($k in $safe.Keys) { $targets[$k] = $safe[$k] }
if ($Aggressive) { foreach ($k in $optional.Keys) { $targets[$k] = $optional[$k] } }

$installed = (& $adb -s $Tv shell pm list packages) -replace '^package:', '' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
$disabled = (& $adb -s $Tv shell pm list packages -d) -replace '^package:', '' | ForEach-Object { $_.Trim() } | Where-Object { $_ }

$found = @()
foreach ($pattern in $targets.Keys) {
    $hits = if ($pattern.EndsWith('*')) { $installed | Where-Object { $_ -like $pattern } } else { $installed | Where-Object { $_ -eq $pattern } }
    foreach ($h in $hits) { $found += [pscustomobject]@{ Package = $h; Why = $targets[$pattern] } }
}
"== Candidates found on this TV: $($found.Count)"
if ($found.Count -eq 0) { "   none of the listed packages exist here: nothing to disable." }

if ($Apply) {
    if (-not (Test-Path (Join-Path $root "backup\packages-enabled.txt"))) {
        throw "No backup found. Run .\tools\backup.ps1 first, so restore.ps1 can undo this."
    }
    "=== lowram run $(Get-Date -Format o) ===" | Out-File -Append -Encoding utf8 $log
}
foreach ($f in $found) {
    if ($disabled -contains $f.Package) { "   SKIP  $($f.Package) (already disabled)"; continue }
    if (-not $Apply) { "   would disable  $($f.Package)  --  $($f.Why)"; continue }
    & $adb -s $Tv shell am force-stop $f.Package 2>&1 | Out-Null
    $out = (& $adb -s $Tv shell pm disable-user --user 0 $f.Package 2>&1) -join ' '
    $status = if ($out -match 'new state: disabled-user') { "OK   " } else { "FAIL " }
    $line = "   $status $($f.Package) -- $($f.Why) [$out]"
    $line
    $line | Out-File -Append -Encoding utf8 $log
}

# ---- storage: clear every app's cache, then (apply only) give Aura an ahead-of-time compile ------
if ($Apply) {
    "== Clearing app caches (frees storage; apps rebuild what they need)"
    (& $adb -s $Tv shell pm trim-caches 400M 2>&1) | ForEach-Object { "   $_" }
    "== Storage (/data) now"
    (& $adb -s $Tv shell df /data) | ForEach-Object { "   $_" }
    "Done. Undo with .\tools\restore.ps1 (re-enables every package disabled here)."
} else {
    "Dry run only. Add -Apply to do it."
}
